package com.ibm.automation.excelOps;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jdom2.Element;

import com.ibm.automation.common.StringUtilsCustom;
import com.ibm.automation.parasoft.DataRow;
import com.ibm.automation.parasoft.domain.ConfigurationTO;


public class ReadExcelDataSheet {
	private static final String FILE_NAME = "C:/Kalpana/TD Bank/datasheets/DocDelivery.xlsx";

	public static void buildDataSources(Element dataSourcesSize, ConfigurationTO configurationTO) {
		
		
	}

	public static InputExcelFileVO parse(String fileNameWithPath)
			throws Exception {
		try {
			FileInputStream spreadsheet = new FileInputStream(new File(
					StringUtilsCustom.getFileNameWithOutSheet(fileNameWithPath)));
			// Create workbook instance to hold file reference to .xlsxfile
			XSSFWorkbook workbook = new XSSFWorkbook(spreadsheet);

			// Get first/desire sheed from the workbook

			XSSFSheet sheet = workbook.getSheet(StringUtilsCustom.getDataSheetName(
					fileNameWithPath).trim());
			Iterator<Row> rows = sheet.rowIterator();

			List<String> headers = new ArrayList<>();
/*			DataFormatter formatter = new DataFormatter();
			if (rows.hasNext()) {
				Row row = rows.next();
				for (Cell cell : row) {
					headers.add(getCellValue(cell));
				}
			}*/
			
			//Read the headers first. Locate the ones you need
			int colNum = sheet.getRow(0).getLastCellNum();
	        XSSFRow rowHeader = sheet.getRow(0);
	        for (int j = 0; j < colNum; j++) {
	            XSSFCell cell = rowHeader.getCell(j);
	            headers.add(cell.getStringCellValue());
	            //String cellValue = getCellValue(cell);
	         
	        }

			List<DataRow> contents = new ArrayList<>();
			while (rows.hasNext()) {
				Row row = rows.next();
				if (!checkIfRowIsEmpty(row) && (row.getRowNum() != 0)) {

					DataRow dataRow = new DataRow();
					dataRow.setIndex(row.getRowNum());
					for (Cell cell : row) {
						// TODO safeguard for header resolving, cell column
						// index
						// might be out of bound of header array
						dataRow.put(headers.get(cell.getColumnIndex()),
								getCellValue(cell));
					}
					System.out.println("dataRow====>" + dataRow);
					contents.add(dataRow);
				}
			}

			return new InputExcelFileVO(headers, contents);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("error while reading excel data"
					+ e.getMessage());
			throw new RuntimeException(e);

		}
	}

	private static String getCellValue(Cell cell) {
		if (cell == null) {
			return null;
		}
		if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
			return cell.getStringCellValue();
		} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			return cell.getNumericCellValue() + "";
		} else if (cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
			return cell.getBooleanCellValue() + "";
		} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
			return cell.getStringCellValue();
		} else if (cell.getCellType() == Cell.CELL_TYPE_ERROR) {
			return cell.getErrorCellValue() + "";
		} else {
			return null;
		}
	}

	private static boolean checkIfRowIsEmpty(Row row) {
		if (row == null) {
			return true;
		}
		if (row.getLastCellNum() <= 0) {
			return true;
		}
		for (int cellNum = row.getFirstCellNum(); cellNum < row
				.getLastCellNum(); cellNum++) {
			Cell cell = row.getCell(cellNum);
			if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK
					&& StringUtils.isNotBlank(cell.toString())) {
				return false;
			}
		}
		return true;
	}

}
