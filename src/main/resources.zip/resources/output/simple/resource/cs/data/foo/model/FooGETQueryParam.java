
package simple.resource.cs.data.foo.model;


public class FooGETQueryParam {

    private String _q;

    public FooGETQueryParam(String q) {
        _q = q;
    }

    public void setQ(String q) {
        _q = q;
    }

    public String getQ() {
        return _q;
    }

}
