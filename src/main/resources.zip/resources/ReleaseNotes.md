**2017-07-26** 

Updates
------

-	implement specifications as per:
	-	[ARCHAPI-2234](https://track.dcts.tdbank.com/browse/ARCHAPI-2234).	