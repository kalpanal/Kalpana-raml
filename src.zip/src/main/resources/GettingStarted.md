
<ul>
	<li>API model and schema: <a href="https://code.td.com/plugins/servlet/archive/projects/APISPEC/repos/docdelivery?at=refs%2Fheads%2Fmaster" target="DOCDELIVERY-OCP_raml">RAML and JSON files</a></li>
	<li>Offline Documentation: <a href="javascript:window.location.assign('http://apispecsdrafts.tdbfg.com/DocumentDeliveries/OCP/0.0.6/OCPDocumentDeliveries%20API%20Reference%20-%20Draft.chm')">CHM File</a></li>
              
</ul>